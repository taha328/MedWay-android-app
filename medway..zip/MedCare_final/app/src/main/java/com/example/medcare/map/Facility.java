package com.example.medcare.map;

public class Facility {
    public String name;
    public String type;
    public double latitude;
    public double longitude;
}
